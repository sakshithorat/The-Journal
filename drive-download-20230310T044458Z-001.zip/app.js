const express = require("express");
const mongoose = require("mongoose");
const Post = require("./models/post");
const postRouter = require('./routes/posts');
const userRoute = require('./routes/user');
const methodOverride = require('method-override');
const app = express();

// mongoose.connect("mongodb+srv://admin-akanksha:26042001@cluster0.xyebm.mongodb.net/blogDB", {useNewUrlParser: true, useUnifiedTopology:true, useCreateIndex: true}); 
mongoose.connect('mongodb://localhost/blogDB', {useNewUrlParser:true, useUnifiedTopology:true, useCreateIndex: true});

app.set('view engine', 'ejs');

app.use(express.static("public"));
app.use(express.urlencoded({extended: false}));
app.use(methodOverride('_method'));

const loremIpsum = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vitae tortor condimentum lacinia quis vel eros donec ac odio. Egestas egestas fringilla phasellus faucibus scelerisque eleifend donec pretium vulputate. Aenean pharetra magna ac placerat vestibulum lectus mauris. Turpis massa sed elementum tempus egestas. Enim nulla aliquet porttitor lacus luctus accumsan tortor. Amet commodo nulla facilisi nullam vehicula ipsum a arcu. Dictum sit amet justo donec enim diam vulputate ut. Morbi tincidunt augue interdum velit euismod in. Pretium lectus quam id leo in vitae. Ornare quam viverra orci sagittis eu volutpat. Cras adipiscing enim eu turpis. Vulputate odio ut enim blandit.";

app.get("/", (req,res) => {
  res.render("posts/homepage");
});

app.get("/journal", async(req, res) => {
    const posts = await Post.find().sort({
      date: 'desc'
    })
    res.render("posts/thejournal", {loremIpsum: loremIpsum, posts: posts});
});

app.get('/signup',(req,res)=> {
  res.render('posts/signup');
})

app.get('/about',(req,res)=>{
  res.render('posts/about',{loremIpsum:loremIpsum});
})

app.get('/contact',(req,res)=>{
  res.render('posts/contact',{loremIpsum:loremIpsum});
})

app.use('/posts', postRouter);
app.use('/auth', userRoute);

app.listen(process.env.PORT || 5000, ()=> {
  console.log("Server started on port 5000");
});


